# Contoso Semantic Model Security Details — sample Power BI project

A ready-to-open **PBIP template** for the Power BI access-audit solution described in the blog series
*"Who Can See What? Auditing Power BI Semantic Model Security in Microsoft Fabric."*

It contains the full six-page audit report and its semantic model, wired to **fabricated sample CSV
data** so it opens with no tenant, no gateway, no service principal and no credentials.

> **All data in this project is fictional.** Workspaces, semantic models, roles, AD groups, users and
> filter expressions were invented for the sample. Any resemblance to a real environment is coincidental.

---

## 1. Open it

**Requires:** Power BI Desktop (a recent version — the project uses the PBIP / TMDL format).

1. Unzip this folder to **`C:\ContosoAccessAudit`** so the data lands at `C:\ContosoAccessAudit\Data`.
2. Open **`Contoso Semantic Model Security Details.pbip`**.
3. Click **Refresh**. Done.

### Unzipped somewhere else?

The model finds the CSVs through a Power Query parameter called **`CsvFolder`**. Point it at your `Data` folder:

- **Home → Transform data → Edit parameters → `CsvFolder`** → paste the full path to the `Data` folder → **OK** → **Refresh**.

Or edit one line in `Contoso Semantic Model Security Details.SemanticModel\definition\expressions.tmdl`
before opening the project:

```tmdl
expression CsvFolder = "C:\ContosoAccessAudit\Data" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
```

---

## 2. What's in the box

```
Contoso Semantic Model Security Details.pbip           <- open this
Contoso Semantic Model Security Details.Report\         report definition (6 pages, PBIR)
Contoso Semantic Model Security Details.SemanticModel\  model definition (TMDL)
Data\                                                   sample CSVs
```

### The report

| Page | Answers | Notes |
|---|---|---|
| **Role - Persona Details** | Who has access, via which role and AD group | Landing page |
| **Security Details** | The RLS DAX filter each role applies | Filtered to `Filter Type = RLS`; buttons toggle to OLS |
| **OLS** *(hidden)* | Which tables/columns a role can't see | Filtered to hidden objects; reached via the toggle |
| **View Security Details** *(hidden)* | One role, end to end | Right-click a role → **Drill through** |
| **AD Group Details** | Group → user membership | |
| **Workspace Access Details** | Workspace roles (Admin/Member/Contributor/Viewer) | |

### The data

| CSV | Loaded as | Rows |
|---|---|---|
| `pbi_model_security_audit_details.csv` | Audit Details | 65 — RLS filters + table/column OLS |
| `pbi_model_security_role_association_details.csv` | Role AD Group Association | 10 |
| `pbi_model_security_adgroup_user_details.csv` | AD Group User Association | 31 (30 users × 12 groups) |
| `pbi_workspace_access_audit_details.csv` | Workspace Access Details | 16 |
| `pbi_role_personas.csv` | Dynamic Role Persona Details | 11 (10 after the `Active = "1"` filter) |
| `pbi_model_details.csv` | *not loaded* — sample of the pipeline's inventory input | 5 |

The CSV column names are deliberately the **snake_case names the Fabric notebooks write** (`Workspace`,
`Semantic_Model`, `Role_Name`, …), so the Power Query steps in this template are the same ones the real
solution uses.

---

## 3. Point it at your own lakehouse

Only the **Source** step changes. Each table's M starts with a comment block showing the swap:

```powerquery-m
// Sample (this template):
Source = Csv.Document(File.Contents(CsvFolder & "\pbi_model_security_audit_details.csv"),
                      [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
dbo_pbi_model_security_audit_details = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),

// Production (your Fabric lakehouse):
Source   = Sql.Databases("<your-endpoint>.datawarehouse.fabric.microsoft.com"),
Database = Source{[Name="pbi_security_audit"]}[Data],
dbo_pbi_model_security_audit_details = Database{[Schema="dbo",Item="pbi_model_security_audit_details"]}[Data],
```

Everything downstream — the renames, the `Key` column, the relationships, the report — stays as-is.
The blog series covers the notebooks that populate those lakehouse tables.

---

## 4. Things worth knowing

- **`Last Updated Time`** is generated in M (`DateTimeZone.UtcNow()` → CST), not from a CSV. It stamps
  every page with the refresh time. Change the offset to suit your timezone.
- **The `Key` column** (`Workspace | Model | Role`) is added in Power Query to `Audit Details` and
  `Role AD Group Association`. A role name alone is ambiguous once two models both define "Viewer".
- **`Group Object ID`** is the join between a role's member (from TOM) and an AD group (from Microsoft
  Graph) — the same Entra object ID on both sides.
- **The three relationships are many-to-many, single-direction.** Filters propagate correctly when you
  select a role/group/user in a slicer. Note that a table visual combining columns from two of these
  tables *without* a measure will show every combination until you slice it — that is inherent to
  many-to-many relationships, not a data problem.
- The sample includes one deliberate **`Filter_Type = ERROR`** row (`Legacy Inventory Semantic Model`),
  showing how the pipeline records "the service principal couldn't read this model" as data rather than
  failing the run.

---

*Shared as a companion to the blog series. Use it, fork it, improve it.*
